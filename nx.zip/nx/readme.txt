Theme Name: NX
Theme URI:
Author: Luca Siano
Author URI:
Description: Starter Theme with Font Awesome and Bootstrap 4
Version: 0.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, custom-header, custom-menu, editor-style, featured-images, sticky-post, translation-ready
Text Domain: nx

This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.
