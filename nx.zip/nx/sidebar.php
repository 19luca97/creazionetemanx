<div class="col-sm-4">
  <?php dynamic_sidebar('primary'); ?>
</div>
