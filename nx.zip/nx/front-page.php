<?php get_header(); ?>

<!-- slider -->

<section class="main-content">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <?php
      $nx_counter = 0;
      $nx_the_query = new WP_Query('category_name=in-evidenza&posts_per_page=3');

      if ( $nx_the_query->have_posts() ) {
        while ( $nx_the_query->have_posts() ) {
          $nx_the_query->the_post();
          $nx_counter++;
          $nx_image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'nx_big' );
            ?>

            <div class="carousel-item <?php echo ($nx_counter == 1 ? 'active' : ''); ?>" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.7)), url(<?php echo esc_url($nx_image_attributes[0]); ?>); background-size: cover; background-position: center center">
            <div class="carousel-caption">
              <h3 class="display-3"><?php the_title(); ?></h3>
              <p><?php the_time('j M Y'); ?> - <?php the_category(', '); ?></p>
              <div class="lead d-none d-lg-block"><?php the_excerpt(); ?></p></div>
            </div>
          </div>

          <?php
        }
        wp_reset_postdata();
      }
      ?>

    </div>

    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</section>

<!-- sezione 2 colonne -->

  <?php
    $nx_the_query = new WP_Query('page_id=30');
    if( $nx_the_query -> have_posts()){
      while( $nx_the_query -> have_posts()){
        $nx_the_query -> the_post();
        ?>

        <section class="container">
          <div class="row mt-5">
            <div class="col-sm-6">
              <blockquote class="blockquote">
                <p class="mr-5 h2"><?php the_title(); ?></p>
                <footer class="blockquote-footer"><?php esc_html_e('Author: ','nx') ?><cite title="Source Title"><?php the_author(); ?></cite></footer>
              </blockquote>
            </div>
            <div class="col-sm-6">
              <?php the_excerpt(); ?>
            </div>
          </div>
        </section>

      <?php
    }
    wp_reset_postdata();
    }
  ?>

  <!-- sezione cards -->

  <section class="container">
    <div class="card-deck mt-5">

      <?php
        $nx_the_query = new WP_Query('category_name=focus&posts_per_page=3');

        if ( $nx_the_query->have_posts() ) {
          while ( $nx_the_query->have_posts() ) {
            $nx_the_query->the_post(); ?>

                <div class="card">
                  <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('nx_single', array('class' => 'img-fluid mb-2', 'alt' => get_the_title() )); ?>
                   </a>


                  <div class="card-body">
                    <div class="card-title"><?php the_title(); ?></div>
                    <div class="card-text"><?php the_excerpt(); ?></div>
                    <p class="card-text"><small class="text-muted"><?php the_time('j M Y'); ?> - <?php the_category(', '); ?></small></p>
                  </div>
                </div>

          <?php
        }
        wp_reset_postdata();
      }
      ?>
    </div>
  </section>

<!-- Sezione jumbotron -->

<?php
  $nx_the_query = new WP_Query('page_id=40');
  if( $nx_the_query -> have_posts()){
    while( $nx_the_query -> have_posts()){
      $nx_the_query -> the_post();
      ?>

      <?php  $nx_image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'nx_big' ); ?>

      <section class="jumbotron jumbotron-fluid mt-5 text-white" style="background: linear-gradient(rgba(0,0,0, 0.6), rgba(0,0,0, 0.7)), url(<?php echo $nx_image_attributes[0]; ?>); background-size: cover; background-position: center center">
        <div class="container">
          <h1 class="display-3"><?php the_title(); ?></h1>
          <div class="lead"><?php the_excerpt(); ?></div>
          <p><?php esc_html_e('Author: ','nx') ?><?php the_author(); ?></p>
          <p class="lead">
            <a class="btn btn-primary btn-lg" href="<?php the_permalink(); ?>" role="button"><?php esc_html_e('Read more...','nx'); ?></a>
          </p>
        </div>
      </section>


    <?php
  }
  wp_reset_postdata();
  }
?>

<?php get_footer(); ?>
