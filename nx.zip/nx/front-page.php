<?php get_header(); ?>

<div class="main-content">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">

      <?php
      $nx_counter = 0;
      $nx_the_query = new WP_Query('category_name=in-evidenza&posts_per_page=3');

      if ( $nx_the_query->have_posts() ) {
        while ( $nx_the_query->have_posts() ) {
          $nx_the_query->the_post();
          $nx_counter++;
          $nx_image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'nx_big' );
          ?>

          <div class="carousel-item <?= ($nx_counter == 1 ? 'active' : '') ?>" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.7)), url(<?= esc_url($nx_image_attributes[0]); ?>); background-size: cover; background-position: center center">
            <div class="carousel-caption">
              <h3 class="display-3"><?php the_title(); ?></h3>
              <p><?php the_time('j M Y'); ?> - <?php the_category(', '); ?></p>
              <div class="lead d-none d-lg-block"><?php the_excerpt(); ?></p></div>
            </div>
          </div>

          <?php
        }
        wp_reset_postdata();
      }
      ?>

    </div>

    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<p class="lead d-none d-lg-block">CIAO A TUTTI</p>


<?php get_footer(); ?>
