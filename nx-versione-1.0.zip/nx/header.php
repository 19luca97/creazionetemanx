<!DOCTYPE html>
<html <?php language_attributes() ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="<?php bloginfo('description') ?>">

  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
  <?php wp_body_open(); ?>
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">

    <div class="container">
      <a class="navbar-brand" href="<?php echo esc_url_raw(home_url()); ?>"><img src="<?php echo get_template_directory_uri() ?>/img/logo.png" alt="logo sito"></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs4navbar" aria-controls="bs4navbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>


      <div class="collapse navbar-collapse" id="bs4navbar">
        <?php
          wp_nav_menu([
            'menu'    => 'header',
            'theme_location'  => 'header',
            'container'   => 'div',
            'container_id'  => 'bs4navbar',
            'container_class' => 'collapse navbar-collapse',
            'menu_id' => false,
            'menu_class'  => 'navbar-nav mr-auto',
            'depth'           => 2,
            'fallback_cb'     => 'bs4navwalker::fallback',
            'walker'          => new bs4navwalker()
          ]);

        ?>
        <form
          class="d-flex align-items-center gap-2 w-100 w-lg-auto mx-lg-3 search-form"
          action="<?php echo esc_url_raw(home_url()); ?>"
          method="get"
        >
        <input
          class="form-control search-input"
          type="search"
          placeholder="Search"
          aria-label="Search"
          name="s"
        >
        <button class="btn icon-search" type="submit">
          <i class="fa-solid fa-magnifying-glass"></i>
        </button>
          </form>

        <ul class="navbar-nav navbar-social push-right">
          <li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
          <li><a href="#"><i class="fa-brands fa-x-twitter"></i></a></li>

        </ul>

      </div>


    </div>
  </nav>
