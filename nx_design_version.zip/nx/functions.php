<?php

// Include custom navwalker
require_once('assets/bs4navwalker.php');

// Register WordPress nav menu
register_nav_menu('top', 'Top menu');

if(! function_exists('nx_setup_theme')){

  function nx_setup_theme(){
    add_theme_support("title-tag");
    add_theme_support( 'automatic-feed-links' );
    add_theme_support("post-thumbnails");
    add_image_size('nx_big',1400,800,true);
    add_image_size('nx_quad',600,600,true);
    add_image_size('nx_news',800,500,true);
    register_nav_menus(array(
      'header' => esc_html__('Header', 'nx'),
    ));

    load_theme_textdomain('nx', get_template_directory().'languages');
  }
}

add_action('after_setup_theme', 'nx_setup_theme');

if(! function_exists('nx_sidebars')){
  function nx_sidebars(){
    register_sidebar(array(
        'name' => esc_html__('Primary', 'nx'),
        'id' => 'primary',
        'description' => esc_html__('Main sidebar', 'nx'),
        'before_title' => '<h3>',
        'after_title' => '</h3>',
        'before_widget' => '<div class="widget my-5 %2$s">',
        'after_widget' => '</div>',
      )
    );
  }
}

add_action('widgets_init', 'nx_sidebars');


if(! function_exists('nx_scripts')){
   function nx_scripts(){
     wp_enqueue_script('nx-popper-js',get_template_directory_uri() .'/js/popper.min.js',array('jquery'),null,true);
     wp_enqueue_script('nx-bootstrap-js',get_template_directory_uri() .'/js/bootstrap.min.js',array('jquery'),null,true);
     wp_enqueue_script('nx-scripts-js',get_template_directory_uri() .'/js/scripts.js',array('jquery'),null,true);
   }
}

 add_action('wp_enqueue_scripts','nx_scripts');


if(! function_exists('nx_styles')){
   function nx_styles(){
     wp_enqueue_style('nx-bootstrap-css',get_template_directory_uri() .'/css/bootstrap.min.css');
     wp_enqueue_style('nx-style-default-css',get_template_directory_uri() .'/style.css');
     wp_enqueue_style('nx-font-awesome',get_template_directory_uri() .'/fontawesome/css/all.min.css');
     wp_enqueue_style('nx-font', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;700&display=swap', false );
   }
}

 add_action('wp_enqueue_scripts','nx_styles');



 function wpdocs_comment_form_defaults( $defaults){
   $defaults['class_submit'] = 'btn btn-primary btn-lg';
   return $defaults;
 }

 add_filter('comment_form_defaults', 'wpdocs_comment_form_defaults');

 ?>
