<?php get_header(); ?>

<!-- slider -->

<section class="main-content">
  <div id="carouselExampleIndicators" class="carousel slide slider-big" data-ride="carousel">
    <div class="carousel-inner">
      <?php
      $nx_counter = 0;

      $args = array(
        'post-type' => 'page',
        'tax_query' => array(
          array(
            'taxonomy' => 'home_visibility',
            'field' => 'slug',
            'terms' => 'slider'
          )
        )
      );

      $nx_the_query = new WP_Query($args);

      if ( $nx_the_query->have_posts() ) {
        while ( $nx_the_query->have_posts() ) {
          $nx_the_query->the_post();
          $nx_counter++;
          $nx_image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'nx_big' );
            ?>

          <div class="carousel-item <?php echo ($nx_counter == 1 ? 'active' : ''); ?>" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.7)), url(<?php echo esc_url($nx_image_attributes[0]); ?>); background-size: cover; background-position: center center">
            <div class="carousel-caption text-left margin-bottom">
              <div class="container">
              <div class="trattino"></div>
                <h3><?php the_title(); ?></h3>
                <div class="carousel-text"><p><?php the_excerpt(); ?></p></div>
                <a href="<?php the_permalink(); ?>" class="btn btn-outline-light btn-lg"><?php esc_html_e('See the video','nx') ?></a>
              </div>
          </div>
        </div>
          <?php
        }
        wp_reset_postdata();
      }
      ?>

    </div>

    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</section>

<!-- Focus -->

<section class="container focuses">
  <div class="row">
    <?php
    $args = array(
      'post-type' => 'page',
      'tax_query' => array(
        array(
          'taxonomy' => 'home_visibility',
          'field' => 'slug',
          'terms' => 'focus'
        )
      )
    );

    $nx_the_query = new WP_Query($args);

    if ( $nx_the_query->have_posts() ) {
      while ( $nx_the_query->have_posts() ) {
          $nx_the_query->the_post();
        ?>
          <div class="col-sm-3 focus">
            <p class="text-intro"><?php the_field('intro_text'); ?></p>
            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <a href="<?php the_permalink(); ?>" class="text-link"><?php esc_html_e('Read more','nx') ?> <i class="fa-solid fa-angle-right"></i></a>
          </div>
        <?php
      }
      wp_reset_postdata();
    }
    ?>
  </div>
</section>



<!-- sezione 2 colonne -->

<?php

  $args = array(
    'post-type' => 'page',
    'tax_query' => array(
      array(
        'taxonomy' => 'home_visibility',
        'field' => 'slug',
        'terms' => 'pre-evidenza'
      )
    )
  );

  $nx_the_query = new WP_Query($args);

  if ( $nx_the_query->have_posts() ) {
    while ( $nx_the_query->have_posts() ) {
      $nx_the_query->the_post();
      ?>

      <section class="container two-columns">
        <div class="trattino"></div>
        <div class="row mt-5">
          <div class="col-sm-6">
            <blockquote class="blockquote">
              <h3 class="two-columns-title"><?php the_title(); ?></h3>
            </blockquote>
          </div>
          <div class="col-sm-6">
            <?php the_excerpt(); ?>
          </div>
        </div>
      </section>

    <?php
  }
  wp_reset_postdata();
}
?>

  <!-- sezione cards -->

  <section class="card-group mt-5">

      <?php
        $args = array(
          'post-type' => 'page',
          'tax_query' => array(
            array(
              'taxonomy' => 'home_visibility',
              'field' => 'slug',
              'terms' => 'in-evidenza'
            )
          )
        );
        $nx_the_query = new WP_Query($args);

        if ( $nx_the_query->have_posts() ) {
          while ( $nx_the_query->have_posts() ) {
            $nx_the_query->the_post();
            $nx_image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'nx_big' ); ?>

            <div class="card card-cover" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.7)), url(<?php echo esc_url($nx_image_attributes[0]); ?>); background-size: cover; background-position: center center">

                  <div class="card-body">
                    <a href="<?php  the_permalink();?>">
                      <h4 class="card-title"><?php the_title(); ?></h4>
                      <div class="card-text"><?php the_excerpt(); ?></div>
                      <p class="card-link"><?php esc_html_e('Scopri di più','nx'); ?><i class="fa-solid fa-angle-right"></i></p>
                   </a>
                  </div>
                </div>

          <?php
        }
        wp_reset_postdata();
      }
      ?>

  </section>

  <!-- 2 Blockquote -->

  <?php

    $args = array(
      'post-type' => 'page',
      'tax_query' => array(
        array(
          'taxonomy' => 'home_visibility',
          'field' => 'slug',
          'terms' => 'post-evidenza'
        )
      )
    );

    $nx_the_query = new WP_Query($args);

    if ( $nx_the_query->have_posts() ) {
      while ( $nx_the_query->have_posts() ) {
        $nx_the_query->the_post();
        ?>

        <section class="container two-blockquote">
          <div class="row mt-5">
            <div class="col-sm-6">
                <?php the_content(); ?>
            </div>
            <div class="col-sm-6">
              <?php the_field('second_content') ?>
            </div>
          </div>
        </section>

      <?php
    }
    wp_reset_postdata();
  }
  ?>

<!-- Sezione jumbotron -->

<?php
  $nx_the_query = new WP_Query('page_id=27');
  if( $nx_the_query -> have_posts()){
    while( $nx_the_query -> have_posts()){
      $nx_the_query -> the_post();
      ?>

      <?php  $nx_image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'nx_big' ); ?>

      <section class="jumbotron jumbotron-fluid mt-5 text-white" style="background: linear-gradient(rgba(0,0,0, 0.6), rgba(0,0,0, 0.7)), url(<?php echo $nx_image_attributes[0]; ?>); background-size: cover; background-position: center center">
        <div class="container">
          <h1 class="display-3"><?php the_title(); ?></h1>
          <div class="lead"><?php the_excerpt(); ?></div>
          <p><?php esc_html_e('Author: ','nx') ?><?php the_author(); ?></p>
          <p class="lead">
            <a class="btn btn-primary btn-lg" href="<?php the_permalink(); ?>" role="button"><?php esc_html_e('Read more...','nx'); ?></a>
          </p>
        </div>
      </section>


    <?php
  }
  wp_reset_postdata();
  }
?>

<?php get_footer(); ?>
