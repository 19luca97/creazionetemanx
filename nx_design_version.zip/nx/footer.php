<footer class="footer bg-dark text-white mt-4">

  <div class="container py-4">
    <p class="mb-0"> <?php esc_html_e('Copyright', 'nx') ?> <?php echo date('o'); ?> - <?php bloginfo('name'); ?> </p>
  </div>

</footer>

<?php wp_footer(); ?>

</body>
</html>
