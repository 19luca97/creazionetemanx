<aside class="col-sm-4">
  <?php dynamic_sidebar('primary'); ?>
</aside>
